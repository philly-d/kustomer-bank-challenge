export const WITHDRAWAL = 'WITHDRAWAL';
export const DEPOSIT = 'DEPOSIT';